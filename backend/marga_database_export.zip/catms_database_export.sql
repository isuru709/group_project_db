-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: catms_db
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment` (
  `appointment_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int DEFAULT NULL,
  `doctor_id` int DEFAULT NULL,
  `branch_id` int DEFAULT NULL,
  `appointment_date` date DEFAULT NULL,
  `appointment_time` time DEFAULT NULL,
  `status` enum('Scheduled','Completed','Cancelled') DEFAULT NULL,
  `created_at` datetime DEFAULT (now()),
  `updated_at` datetime DEFAULT (now()),
  PRIMARY KEY (`appointment_id`),
  KEY `appointment_ibfk_1` (`patient_id`),
  KEY `appointment_ibfk_2` (`doctor_id`),
  KEY `appointment_ibfk_3` (`branch_id`),
  CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `staff` (`staff_id`),
  CONSTRAINT `appointment_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (1,2,2,1,'2025-09-20','09:00:00','Scheduled','2025-09-17 22:40:27','2025-09-17 22:40:27'),(2,2,3,1,'2025-09-25','14:00:00','Scheduled','2025-09-17 22:40:27','2025-09-17 22:40:27');
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointment_history`
--

DROP TABLE IF EXISTS `appointment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointment_history` (
  `history_id` int NOT NULL AUTO_INCREMENT,
  `appointment_id` int DEFAULT NULL,
  `previous_status` enum('Scheduled','Completed','Cancelled') DEFAULT NULL,
  `new_status` enum('Scheduled','Completed','Cancelled') DEFAULT NULL,
  `reason` text,
  `modified_by` int DEFAULT NULL,
  `modified_at` datetime DEFAULT (now()),
  PRIMARY KEY (`history_id`),
  KEY `appointment_history_ibfk_1` (`appointment_id`),
  KEY `appointment_history_ibfk_2` (`modified_by`),
  CONSTRAINT `appointment_history_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`appointment_id`),
  CONSTRAINT `appointment_history_ibfk_2` FOREIGN KEY (`modified_by`) REFERENCES `staff` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment_history`
--

LOCK TABLES `appointment_history` WRITE;
/*!40000 ALTER TABLE `appointment_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointment_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `appointment_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `doctor_id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `appointment_date` datetime NOT NULL,
  `status` enum('Pending','Approved','Rejected','Scheduled','Completed','Cancelled','No-Show') DEFAULT NULL,
  `is_walkin` tinyint(1) DEFAULT '0',
  `reason` text,
  `created_by` int DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `rejection_reason` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`appointment_id`),
  UNIQUE KEY `idx_unique_appointment` (`doctor_id`,`appointment_date`),
  KEY `branch_id` (`branch_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_appointments_patient` (`patient_id`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  CONSTRAINT `appointments_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (1,1,2,1,'2025-09-02 10:00:00','Scheduled',0,'General checkup',NULL,NULL,NULL,NULL,'2025-09-01 11:05:57'),(2,2,2,NULL,'2025-12-20 04:30:00','Pending',0,'heart case',NULL,NULL,NULL,NULL,'2025-10-20 14:05:34'),(3,2,3,NULL,'2025-12-26 04:50:00','Pending',0,'heart',NULL,NULL,NULL,NULL,'2025-10-20 14:09:20');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `action` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `target_table` varchar(50) DEFAULT NULL,
  `target_id` int DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch` (
  `branch_id` int NOT NULL AUTO_INCREMENT,
  `branch_name` varchar(20) DEFAULT NULL,
  `location` varchar(20) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `created_at` datetime DEFAULT (now()),
  PRIMARY KEY (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,'Main Branch','Colombo','0112345678','2025-09-17 22:39:12'),(2,'Branch 2','Kandy','0812345678','2025-09-17 22:39:12');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `branch_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`branch_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,'Main Clinic','123 Medical Center Dr','+1-555-0123','main@catms.com');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor_specialties`
--

DROP TABLE IF EXISTS `doctor_specialties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor_specialties` (
  `user_id` int NOT NULL,
  `specialty_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`specialty_id`),
  KEY `specialty_id` (`specialty_id`),
  CONSTRAINT `doctor_specialties_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `doctor_specialties_ibfk_2` FOREIGN KEY (`specialty_id`) REFERENCES `specialties` (`specialty_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor_specialties`
--

LOCK TABLES `doctor_specialties` WRITE;
/*!40000 ALTER TABLE `doctor_specialties` DISABLE KEYS */;
/*!40000 ALTER TABLE `doctor_specialties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance_claim`
--

DROP TABLE IF EXISTS `insurance_claim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance_claim` (
  `claim_id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int DEFAULT NULL,
  `policy_id` int DEFAULT NULL,
  `claim_amount` decimal(10,2) DEFAULT NULL,
  `submission_date` date DEFAULT (now()),
  `claim_status` enum('Submitted','Approved','Rejected') DEFAULT NULL,
  `reimbursement_amount` decimal(10,2) DEFAULT NULL,
  `denial_reason` text,
  `created_at` datetime DEFAULT (now()),
  PRIMARY KEY (`claim_id`),
  KEY `insurance_claim_ibfk_1` (`invoice_id`),
  KEY `insurance_claim_ibfk_2` (`policy_id`),
  CONSTRAINT `insurance_claim_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`),
  CONSTRAINT `insurance_claim_ibfk_2` FOREIGN KEY (`policy_id`) REFERENCES `insurance_policy` (`policy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance_claim`
--

LOCK TABLES `insurance_claim` WRITE;
/*!40000 ALTER TABLE `insurance_claim` DISABLE KEYS */;
/*!40000 ALTER TABLE `insurance_claim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance_claims`
--

DROP TABLE IF EXISTS `insurance_claims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance_claims` (
  `claim_id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `provider_name` varchar(100) DEFAULT NULL,
  `claim_status` enum('Submitted','Paid','Rejected','Pending') DEFAULT 'Pending',
  `submitted_at` datetime DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `response_notes` text,
  PRIMARY KEY (`claim_id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `insurance_claims_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance_claims`
--

LOCK TABLES `insurance_claims` WRITE;
/*!40000 ALTER TABLE `insurance_claims` DISABLE KEYS */;
/*!40000 ALTER TABLE `insurance_claims` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance_policy`
--

DROP TABLE IF EXISTS `insurance_policy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance_policy` (
  `policy_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int DEFAULT NULL,
  `provider_name` varchar(25) DEFAULT NULL,
  `policy_number` varchar(10) DEFAULT NULL,
  `coverage_percentage` decimal(5,2) DEFAULT NULL,
  `deductable` decimal(10,2) DEFAULT NULL,
  `expiry_date` date DEFAULT (curdate()),
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT (now()),
  PRIMARY KEY (`policy_id`),
  KEY `insurance_policy_ibfk_1` (`patient_id`),
  CONSTRAINT `insurance_policy_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance_policy`
--

LOCK TABLES `insurance_policy` WRITE;
/*!40000 ALTER TABLE `insurance_policy` DISABLE KEYS */;
/*!40000 ALTER TABLE `insurance_policy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `invoice_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int DEFAULT NULL,
  `appointment_id` int DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `insurance_amount` decimal(10,2) DEFAULT NULL,
  `patient_amount` decimal(10,2) DEFAULT NULL,
  `status` enum('Pending','Paid','Cancelled') DEFAULT NULL,
  `created_at` datetime DEFAULT (now()),
  `due_date` datetime DEFAULT (now()),
  PRIMARY KEY (`invoice_id`),
  KEY `invoice_ibfk_1` (`patient_id`),
  KEY `invoice_ibfk_2` (`appointment_id`),
  CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`appointment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,2,1,50.00,0.00,50.00,'Pending','2025-09-17 22:40:27','2025-09-17 22:40:27'),(2,2,2,100.00,20.00,80.00,'Pending','2025-09-17 22:40:27','2025-09-17 22:40:27');
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `invoice_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `appointment_id` int DEFAULT NULL,
  `branch_id` int DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `paid_amount` decimal(10,2) DEFAULT '0.00',
  `due_date` date DEFAULT NULL,
  `status` enum('Pending','Partially Paid','Paid','Refunded') DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`invoice_id`),
  KEY `patient_id` (`patient_id`),
  KEY `appointment_id` (`appointment_id`),
  KEY `branch_id` (`branch_id`),
  KEY `idx_invoices_status` (`status`),
  CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`),
  CONSTRAINT `invoices_ibfk_2` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`),
  CONSTRAINT `invoices_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,1,1,1,50.00,0.00,NULL,'Pending','2025-09-01 11:07:43');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_auth`
--

DROP TABLE IF EXISTS `patient_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_auth` (
  `auth_id` int NOT NULL AUTO_INCREMENT,
  `patient_id` int NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `email_verified` tinyint(1) DEFAULT '0',
  `verification_token` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `verification_token_expires` timestamp NULL DEFAULT NULL COMMENT 'Expiry time for verification token',
  PRIMARY KEY (`auth_id`),
  UNIQUE KEY `patient_id` (`patient_id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_patient_email` (`email`),
  KEY `idx_patient_verification` (`verification_token`),
  KEY `idx_patient_reset` (`reset_token`),
  CONSTRAINT `patient_auth_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`patient_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_auth`
--

LOCK TABLES `patient_auth` WRITE;
/*!40000 ALTER TABLE `patient_auth` DISABLE KEYS */;
INSERT INTO `patient_auth` VALUES (1,10,'patient@catms.com','$2b$10$hvWmzmGPy.hT0mE8Q7gt1ORSLgdrN779YtJsVNBsxR8MZMuyDMFPW',1,1,NULL,NULL,NULL,'2025-09-26 15:44:01','2025-09-26 20:02:15','2025-09-26 15:44:01',NULL),(2,11,'amalsilva@gmail.com','$2b$10$T9I/eKnVyifGF.W5bHHeyuSqjGrSOETbInS/N2u2vardVq0XAcm5O',1,1,'6e146af506b9b37dc0899bba722e9e0bf0249505ddd9730960e12e3349adebc1',NULL,NULL,NULL,'2025-10-17 05:53:02','2025-10-17 05:53:02',NULL);
/*!40000 ALTER TABLE `patient_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `patient_id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `national_id` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `blood_type` varchar(3) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `address` text,
  `emergency_contact` varchar(10) DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `emergency_contact_phone` varchar(20) DEFAULT NULL,
  `insurance_provider` varchar(100) DEFAULT NULL,
  `insurance_policy_number` varchar(50) DEFAULT NULL,
  `allergies` text,
  `profile_picture` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `first_name` varchar(25) GENERATED ALWAYS AS (substring_index(`full_name`,_utf8mb4' ',1)) STORED,
  `last_name` varchar(25) GENERATED ALWAYS AS ((case when ((char_length(`full_name`) - char_length(replace(`full_name`,_utf8mb4' ',_utf8mb4''))) > 0) then substr(`full_name`,(char_length(substring_index(`full_name`,_utf8mb4' ',1)) + 2)) else NULL end)) STORED,
  `date_of_birth` date DEFAULT NULL,
  `nic` varchar(20) DEFAULT NULL COMMENT 'National ID Card number',
  `emergency_contact_relationship` varchar(50) DEFAULT NULL,
  `chronic_conditions` text COMMENT 'Chronic medical conditions',
  `current_medications` text COMMENT 'Current medications',
  `occupation` varchar(100) DEFAULT NULL,
  `marital_status` enum('Single','Married','Divorced','Widowed','Other') DEFAULT 'Other',
  PRIMARY KEY (`patient_id`),
  UNIQUE KEY `national_id` (`national_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `nic` (`nic`),
  KEY `idx_patients_name` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` (`patient_id`, `full_name`, `national_id`, `dob`, `gender`, `blood_type`, `phone`, `email`, `password_hash`, `address`, `emergency_contact`, `emergency_contact_name`, `emergency_contact_phone`, `insurance_provider`, `insurance_policy_number`, `allergies`, `profile_picture`, `active`, `created_at`, `date_of_birth`, `nic`, `emergency_contact_relationship`, `chronic_conditions`, `current_medications`, `occupation`, `marital_status`) VALUES (1,'John Doe','123456789','1990-01-01','Male','O+','+1234567890','john.doe@example.com',NULL,'123 Main St',NULL,'Jane Doe','+1234567891',NULL,NULL,'None',NULL,1,'2025-09-01 11:05:41',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(2,'Kusal Test','N123456789','1990-01-01','Male','','1234567890','kusal@gmail.com','$2b$10$h.DMZo847ivR8Ev1P7fVS.RPwrmXJzjeCIIWl8CgL1h/I.LxiRIa6','Test Address','',NULL,NULL,NULL,NULL,'','http://localhost:5000/uploads/profile-pictures/patient-2-1760896161208-284137443.jpeg',1,'2025-09-17 15:54:52',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(3,'manike','200413412167','2004-08-09','Male',NULL,'0715678904','manike@gmail.com','$2b$10$Q1ruyB1qxEacHpwZlwcY9.0KD2dWkJaZB74ErB6h/doMOBXQJQixS','Manike home,galle',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:05:11',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(4,'Test Patient','T123456789','1995-01-01','Female',NULL,'9876543210','test@example.com','$2b$10$J2662QkeCEnai1bX/J9DfOwtB4.mU2tq3qc.4XW9FMRTANm4k6Wk6','Test Address',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:06:12',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(5,'Frontend Test','F123456789','1995-01-01','Female',NULL,'9876543210','frontend@test.com','$2b$10$6qVYSe/YcBmQX5ttMZHIEu8lYeBbDJV7vTvDSRuaXKO0Qy4F5QvGC','Test Address',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:11:58',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(6,'thumpane','200314513167','1997-06-02','Male',NULL,'0716720764','thum@gmail.com','$2b$10$0w2mb8XUpNmTMjt7.yzUM.5iFHz9XE1ZXwAJ/pScOfIMbwKREEtH2','Thumpane,Galle',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:52:40',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(7,'hashini','200315678290','2001-06-02','Female',NULL,'0716720869','hashini@gmail.com','$2b$10$yvEKhJVEZPSR80LScYy/PO3VQyRT07sosPrIdVzmK5Kgo88fyNCly','Tangalle,Galle',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 18:16:56',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(8,'nikini','200315413161','2003-06-02','Female',NULL,'0716789561','nikini@gmail.com','$2b$10$Cc6q2gGLtM73Wu1Mbb4ZjOsxcYRMJ21l390FAhOYiVTVSL/4SfHVO','Nikini,Galle',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 18:24:37',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(9,'kumari','200315413160','1990-06-02','Female','','0716708561','kumari@gmail.com','$2b$10$umqiH0X6433fWw3CYmGhvurraiOQZnUNO.hMYhKQxYnCw/tB4eqLW','Kumari home,Galle',NULL,NULL,NULL,NULL,NULL,'','/uploads/profile-pictures/patient-9-1758176042598-886685630.png',1,'2025-09-18 06:13:24',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(10,'John Doe Patient','TEST001','1985-01-01','Male',NULL,'+1234567890','patient@catms.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-09-26 14:32:15',NULL,NULL,NULL,NULL,NULL,NULL,'Other'),(11,'Amal Silva',NULL,'2003-06-02',NULL,NULL,'+94 789920564','amalsilva@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-10-17 05:53:02',NULL,NULL,NULL,NULL,NULL,NULL,'Other');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients_backup`
--

DROP TABLE IF EXISTS `patients_backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients_backup` (
  `patient_id` int NOT NULL DEFAULT '0',
  `full_name` varchar(100) NOT NULL,
  `national_id` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `blood_type` varchar(3) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `address` text,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `emergency_contact_phone` varchar(20) DEFAULT NULL,
  `insurance_provider` varchar(100) DEFAULT NULL,
  `insurance_policy_number` varchar(50) DEFAULT NULL,
  `allergies` text,
  `active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients_backup`
--

LOCK TABLES `patients_backup` WRITE;
/*!40000 ALTER TABLE `patients_backup` DISABLE KEYS */;
INSERT INTO `patients_backup` VALUES (1,'John Doe','123456789','1990-01-01','Male','O+','+1234567890','john.doe@example.com',NULL,'123 Main St','Jane Doe','+1234567891',NULL,NULL,'None',1,'2025-09-01 11:05:41','John','Doe'),(2,'Kusal Test','N123456789','1990-01-01','Male',NULL,'1234567890','kusal@gmail.com','$2b$10$h.DMZo847ivR8Ev1P7fVS.RPwrmXJzjeCIIWl8CgL1h/I.LxiRIa6','Test Address',NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 15:54:52','Kusal','Test'),(3,'manike','200413412167','2004-08-09','Male',NULL,'0715678904','manike@gmail.com','$2b$10$Q1ruyB1qxEacHpwZlwcY9.0KD2dWkJaZB74ErB6h/doMOBXQJQixS','Manike home,galle',NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:05:11','manike',NULL),(4,'Test Patient','T123456789','1995-01-01','Female',NULL,'9876543210','test@example.com','$2b$10$J2662QkeCEnai1bX/J9DfOwtB4.mU2tq3qc.4XW9FMRTANm4k6Wk6','Test Address',NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:06:12','Test','Patient'),(5,'Frontend Test','F123456789','1995-01-01','Female',NULL,'9876543210','frontend@test.com','$2b$10$6qVYSe/YcBmQX5ttMZHIEu8lYeBbDJV7vTvDSRuaXKO0Qy4F5QvGC','Test Address',NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:11:58','Frontend','Test'),(6,'thumpane','200314513167','1997-06-02','Male',NULL,'0716720764','thum@gmail.com','$2b$10$0w2mb8XUpNmTMjt7.yzUM.5iFHz9XE1ZXwAJ/pScOfIMbwKREEtH2','Thumpane,Galle',NULL,NULL,NULL,NULL,NULL,1,'2025-09-17 16:52:40','thumpane',NULL);
/*!40000 ALTER TABLE `patients_backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_method` enum('Cash','Card','Insurance','Online') DEFAULT NULL,
  `transaction_reference` varchar(25) DEFAULT NULL,
  `status` enum('Pending','Paid','Cancelled') DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`payment_id`),
  KEY `payment_ibfk_1` (`invoice_id`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `invoice_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` enum('Cash','Card','Bank Transfer','Mobile Wallet') NOT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `payment_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `invoice_id` (`invoice_id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (5,'Billing Staff'),(2,'Branch Manager'),(3,'Doctor'),(6,'Patient'),(4,'Receptionist'),(1,'System Administrator');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specialties`
--

DROP TABLE IF EXISTS `specialties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `specialties` (
  `specialty_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`specialty_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specialties`
--

LOCK TABLES `specialties` WRITE;
/*!40000 ALTER TABLE `specialties` DISABLE KEYS */;
/*!40000 ALTER TABLE `specialties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `staff_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `role` enum('Admin','Doctor','Nurse','Receptionist','Other') NOT NULL,
  `speciality` varchar(25) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `branch_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`staff_id`),
  KEY `staff_ibfk_1` (`branch_id`),
  CONSTRAINT `staff_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'Admin','User','Admin','Administration','admin@catms.com',1,'2025-09-17 22:39:12',1),(2,'Dr. John','Smith','Doctor','Cardiology','john.smith@catms.com',1,'2025-09-17 22:39:12',1),(3,'Dr. Jane','Doe','Doctor','Neurology','jane.doe@catms.com',1,'2025-09-17 22:39:12',1),(4,'Nurse','Mary','Nurse','General','mary.nurse@catms.com',1,'2025-09-17 22:39:12',1),(5,'Reception','Staff','Receptionist','Administration','reception@catms.com',1,'2025-09-17 22:39:12',1);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_branch_access`
--

DROP TABLE IF EXISTS `staff_branch_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_branch_access` (
  `access_id` int NOT NULL AUTO_INCREMENT,
  `staff_id` int DEFAULT NULL,
  `branch_id` int DEFAULT NULL,
  `access_level` enum('Read','Write','Admin','Owner') DEFAULT NULL,
  `granted_at` datetime DEFAULT (now()),
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`access_id`),
  KEY `staff_branch_access_ibfk_1` (`staff_id`),
  KEY `staff_branch_access_ibfk_2` (`branch_id`),
  CONSTRAINT `staff_branch_access_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`),
  CONSTRAINT `staff_branch_access_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_branch_access`
--

LOCK TABLES `staff_branch_access` WRITE;
/*!40000 ALTER TABLE `staff_branch_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_branch_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_schedule`
--

DROP TABLE IF EXISTS `staff_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff_schedule` (
  `schedule_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `day_of_week` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`schedule_id`),
  KEY `user_id` (`user_id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `staff_schedule_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `staff_schedule_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_schedule`
--

LOCK TABLES `staff_schedule` WRITE;
/*!40000 ALTER TABLE `staff_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `staff_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `setting_id` int NOT NULL AUTO_INCREMENT,
  `key_name` varchar(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`setting_id`),
  UNIQUE KEY `key_name` (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment`
--

DROP TABLE IF EXISTS `treatment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatment` (
  `treatment_id` int NOT NULL AUTO_INCREMENT,
  `appointment_id` int DEFAULT NULL,
  `treatment_type_id` int DEFAULT NULL,
  `consultation_notes` text,
  `prescription` text,
  `treatment_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `cost` decimal(10,2) DEFAULT NULL,
  `doctor_signature` text,
  `created_at` datetime DEFAULT (now()),
  PRIMARY KEY (`treatment_id`),
  KEY `treatment_ibfk_1` (`appointment_id`),
  KEY `treatment_ibfk_2` (`treatment_type_id`),
  CONSTRAINT `treatment_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`appointment_id`),
  CONSTRAINT `treatment_ibfk_2` FOREIGN KEY (`treatment_type_id`) REFERENCES `treatment_catalogue` (`treatment_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment`
--

LOCK TABLES `treatment` WRITE;
/*!40000 ALTER TABLE `treatment` DISABLE KEYS */;
INSERT INTO `treatment` VALUES (1,1,1,'Patient complains of chest pain. Recommend further tests.','Prescribed medication for pain relief','2025-09-17 22:40:27',50.00,NULL,'2025-09-17 22:40:27'),(2,2,2,'Blood test results show normal range','Continue current medication','2025-09-17 22:40:27',25.00,NULL,'2025-09-17 22:40:27');
/*!40000 ALTER TABLE `treatment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment_catalogue`
--

DROP TABLE IF EXISTS `treatment_catalogue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatment_catalogue` (
  `treatment_type_id` int NOT NULL AUTO_INCREMENT,
  `treatment_name` varchar(25) DEFAULT NULL,
  `description` text,
  `icd10_code` varchar(7) DEFAULT NULL,
  `cpt_code` varchar(5) DEFAULT NULL,
  `standard_cost` decimal(10,2) DEFAULT NULL,
  `category` varchar(25) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`treatment_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_catalogue`
--

LOCK TABLES `treatment_catalogue` WRITE;
/*!40000 ALTER TABLE `treatment_catalogue` DISABLE KEYS */;
INSERT INTO `treatment_catalogue` VALUES (1,'General Consultation','General medical consultation','Z00.00','99213',50.00,'Consultation',1),(2,'Blood Test','Complete blood count test','Z13.1','85025',25.00,'Diagnostic',1),(3,'X-Ray','Chest X-ray examination','Z87.891','71020',75.00,'Imaging',1);
/*!40000 ALTER TABLE `treatment_catalogue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatment_records`
--

DROP TABLE IF EXISTS `treatment_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatment_records` (
  `record_id` int NOT NULL AUTO_INCREMENT,
  `appointment_id` int NOT NULL,
  `doctor_id` int NOT NULL,
  `treatment_id` int NOT NULL,
  `notes` text,
  `prescription` text,
  `image_url` text,
  `digitally_signed` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`record_id`),
  KEY `appointment_id` (`appointment_id`),
  KEY `treatment_id` (`treatment_id`),
  KEY `idx_treatment_records_doc` (`doctor_id`),
  CONSTRAINT `treatment_records_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`) ON DELETE CASCADE,
  CONSTRAINT `treatment_records_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `treatment_records_ibfk_3` FOREIGN KEY (`treatment_id`) REFERENCES `treatments` (`treatment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatment_records`
--

LOCK TABLES `treatment_records` WRITE;
/*!40000 ALTER TABLE `treatment_records` DISABLE KEYS */;
/*!40000 ALTER TABLE `treatment_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatments`
--

DROP TABLE IF EXISTS `treatments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatments` (
  `treatment_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `cost` decimal(10,2) NOT NULL,
  `duration` int DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `icd10_code` varchar(20) DEFAULT NULL,
  `cpt_code` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`treatment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatments`
--

LOCK TABLES `treatments` WRITE;
/*!40000 ALTER TABLE `treatments` DISABLE KEYS */;
INSERT INTO `treatments` VALUES (1,'General Checkup','Routine health examination',50.00,NULL,NULL,'Z00.00','99385',1);
/*!40000 ALTER TABLE `treatments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_session`
--

DROP TABLE IF EXISTS `user_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_session` (
  `session_id` varchar(128) NOT NULL,
  `staff_id` int DEFAULT NULL,
  `login_time` datetime DEFAULT NULL,
  `logout_time` datetime DEFAULT NULL,
  `ip_address` varchar(61) DEFAULT NULL,
  `status` enum('Active','Expired') DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  KEY `user_session_ibfk_1` (`staff_id`),
  CONSTRAINT `user_session_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`staff_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_session`
--

LOCK TABLES `user_session` WRITE;
/*!40000 ALTER TABLE `user_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `branch_id` int DEFAULT NULL,
  `role_id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `branch_id` (`branch_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`) ON DELETE SET NULL,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,1,'System Administrator','admin@catms.com',NULL,'$2b$10$RAagOMCYcA/3h5iI/uDHG.A/En7C3vxMMfWen.gYdS2FTmPqzZcL.',1,'2025-09-01 10:43:59',NULL),(2,1,3,'Dr. John Smith','doctor@catms.com',NULL,'$2b$10$un9h9Pc4WhoNFqPyDtywS.3VxP/tWPSnD0cHO4d79s/RgfWT3los2',1,'2025-09-01 10:43:59',NULL),(3,1,3,'Test User','test@catms.com',NULL,'$2b$10$6s416j9Spo60K4Q61Qp87ewKAEKvAWX.NaT6sJjuBOksw0xKpy.sC',1,'2025-09-01 10:51:10',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'catms_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-20 20:02:37
